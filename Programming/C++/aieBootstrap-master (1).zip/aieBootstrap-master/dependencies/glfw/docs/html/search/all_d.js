var searchData=
[
  ['standards_20conformance',['Standards conformance',['../compat_guide.html',1,'']]],
  ['standard_20cursor_20shapes',['Standard cursor shapes',['../group__shapes.html',1,'']]],
  ['size',['size',['../structGLFWgammaramp.html#ad620e1cffbff9a32c51bca46301b59a5',1,'GLFWgammaramp']]]
];
